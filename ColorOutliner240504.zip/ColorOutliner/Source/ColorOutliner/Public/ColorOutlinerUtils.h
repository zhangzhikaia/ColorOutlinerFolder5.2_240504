// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once

struct FActorFolderTreeItem;
struct FActorTreeItem;

/*Debug macros*/
#if 0
#define DoubleToString UKismetStringLibrary::Conv_DoubleToString

#define Sleep(Frame) std::this_thread::sleep_for(std::chrono::milliseconds(Frame))

#define NewThread(Execute) std::thread([&]() {Execute}).detach()
#endif

/*Debug functions*/
#if 0
namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
	}
	static void Print(const int32& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
	}
	static void Print(const FText& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
	}
	static void FastPrint()
	{
		Print(TEXT("FastPring : Debug"));
	}
}
#endif

/*Utility*/
namespace SceneOutlinerFolderUtils
{
	FLinearColor GetOutlinerItemDefaultColor(bool bIsFolder);

	FString GetSectionName();
	
	FName GetDefaultContextBaseMenuName();

	/*Append current map path with inFolder's path / inActor's guid*/
	const FString GetFolderFullPath(const FActorFolderTreeItem* SelectedFolder);
	const FString GetFolderFullPath(const FFolder& Folder);
	
	const FString GetActorFullPath(const FActorTreeItem* SelectedActor);
	const FString GetActorFullPath(const AActor* InActor);
	
	/*Input path,Find color from config INI*/
	TOptional<FLinearColor> GetColorByPath(const FString& InFullPath,bool bIsFolder);
	TOptional<FLinearColor> GetColorByPathTemp(const FString& InTempPath);
	
	/*OnColorClicked, save in config*/
	void SaveColorWithPath(const FString& InFullPath, TOptional<FLinearColor> InColor,bool bIsFolder);
	void SaveColorWithPathTemp(const FString& InTempPath, TOptional<FLinearColor> InColor,bool bIsFolder);
	
	/*OnRowConstruct*/
	void SetIconColor(TSharedPtr<SWidget> RowWidget,const FLinearColor InColor);
	
	/*On Tear Down World*/
	void ClearColorsTemp();

	/*On Temp map save as a map asset ,Take temp TMap property to config */
	void TempToSave(const UWorld* World);

	/*MapRename Event */
	/*OnPreWorldRename , save its old name , when renamed , find old name in config and replace its*/
	void OnPreWorldRename(UWorld* World);
	/*OnPostWorldRename ,  find old name in config and replace its*/
	void OnPostWorldRename(UWorld* World);

	/*MapDelete Event*/
	/*OnAssetsPreDelete , save its path , when deleted , find path in config and clear it.*/
	void OnWorldPreDelete(const TArray<UObject*>& Objects);
	/*OnAssetsDeleted, find path in config and clear it. (assets was deleted, no path data , should save them before delete*/
	void OnWorldDeleted();

	/*FolderOperate Event*/
	/*OnFolderMoved , update path in config*/
	void UpdateFolderFullPath(const FFolder& Source, const FFolder& Dest);
	/*OnFolderDeleted, delete path in config*/
	void DeleteFolderFullPath(const FFolder& Folder);

	/*OnActorDeleted, delete path in config*/
	void DeleteActorFullPath(const AActor* InActor);
	
	/*When open map,check it if temp map, save it bool*/
	void SaveIsTempMap(const bool IsTemp);
	/*Is current map temp? */
	const bool GetIsTempMap();

	/*On LoadMap , Save current map's asset path to a FString*/
	void SaveCurrentMapPath(const FString InMapPath);
	/*return now map's asset path*/
	FString GetCurrentMapPath();

	void SaveIsFolderMoved(const bool IsMoved);
	const bool GetIsFolderMoved();

	void SaveIsCurrentMapRenamed(bool bInIsCurrentMap);
	bool GetIsCurrentMapRenamed();
	
	/*OnClearColor*/
	void DeleteFullPathFromConfig(const FString InPath);
	/*OnClearColor _ In temp map*/
	void DeleteFullPathFromTemp(const FString InPath);
	
	/*On Shutdown*/
	void ClearCache();
}
